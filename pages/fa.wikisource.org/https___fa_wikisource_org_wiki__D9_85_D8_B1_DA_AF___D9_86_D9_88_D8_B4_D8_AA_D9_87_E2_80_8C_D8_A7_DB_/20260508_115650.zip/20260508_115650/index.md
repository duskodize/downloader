# Visited: https://fa.wikisource.org/wiki/%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)
**Time:** Fri May  8 11:57:12 UTC 2026

## Screenshot
![Screenshot](./screenshot.png)

## Raw HTML
[page.html](./page.html)

## Downloaded Media (0 files)
_No media files downloaded_

## Other Links
- [#](#)
- [#bodyContent](#bodyContent)
- [//commons.wikimedia.org/wiki/Special:UploadWizard?setlang=fa&amp;campaign=fa](//commons.wikimedia.org/wiki/Special:UploadWizard?setlang=fa&amp;campaign=fa)
- [//fa.wikisource.org/w/api.php?action=rsd](//fa.wikisource.org/w/api.php?action=rsd)
- [//fa.wikisource.org/w/index.php?title=%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;mobileaction=toggle_view_mobile](//fa.wikisource.org/w/index.php?title=%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;mobileaction=toggle_view_mobile)
- [//meta.wikimedia.org](//meta.wikimedia.org)
- [/w/index.php?title=%D8%A8%D8%AD%D8%AB:%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;action=edit&amp;redlink=1](/w/index.php?title=%D8%A8%D8%AD%D8%AB:%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;action=edit&amp;redlink=1)
- [/w/index.php?title=%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;action=edit](/w/index.php?title=%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;action=edit)
- [/w/index.php?title=%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;action=history](/w/index.php?title=%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;action=history)
- [/w/index.php?title=%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;action=info](/w/index.php?title=%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;action=info)
- [/w/index.php?title=%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;oldid=277501](/w/index.php?title=%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)&amp;oldid=277501)
- [/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%D8%A7%DB%8C%D8%AC%D8%A7%D8%AF_%D8%AD%D8%B3%D8%A7%D8%A8_%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%DB%8C&amp;returnto=%D9%85%D8%B1%DA%AF+%28%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C+%DA%A9%D9%88%D8%AA%D8%A7%D9%87%29](/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%D8%A7%DB%8C%D8%AC%D8%A7%D8%AF_%D8%AD%D8%B3%D8%A7%D8%A8_%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%DB%8C&amp;returnto=%D9%85%D8%B1%DA%AF+%28%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C+%DA%A9%D9%88%D8%AA%D8%A7%D9%87%29)
- [/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%D8%AA%D8%BA%DB%8C%DB%8C%D8%B1%D8%A7%D8%AA_%D8%A7%D8%AE%DB%8C%D8%B1&amp;feed=atom](/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%D8%AA%D8%BA%DB%8C%DB%8C%D8%B1%D8%A7%D8%AA_%D8%A7%D8%AE%DB%8C%D8%B1&amp;feed=atom)
- [/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%D9%88%D8%B1%D9%88%D8%AF_%D8%A8%D9%87_%D8%B3%D8%A7%D9%85%D8%A7%D9%86%D9%87&amp;returnto=%D9%85%D8%B1%DA%AF+%28%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C+%DA%A9%D9%88%D8%AA%D8%A7%D9%87%29](/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%D9%88%D8%B1%D9%88%D8%AF_%D8%A8%D9%87_%D8%B3%D8%A7%D9%85%D8%A7%D9%86%D9%87&amp;returnto=%D9%85%D8%B1%DA%AF+%28%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C+%DA%A9%D9%88%D8%AA%D8%A7%D9%87%29)
- [/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%DB%8C%D8%A7%D8%AF%DA%A9%D8%B1%D8%AF&amp;page=%D9%85%D8%B1%DA%AF_%28%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87%29&amp;id=277501&amp;wpFormIdentifier=titleform](/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:%DB%8C%D8%A7%D8%AF%DA%A9%D8%B1%D8%AF&amp;page=%D9%85%D8%B1%DA%AF_%28%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87%29&amp;id=277501&amp;wpFormIdentifier=titleform)
- [/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:UrlShortener&amp;url=https%3A%2F%2Ffa.wikisource.org%2Fwiki%2F%25D9%2585%25D8%25B1%25DA%25AF_%28%25D9%2586%25D9%2588%25D8%25B4%25D8%25AA%25D9%2587%25E2%2580%258C%25D8%25A7%25DB%258C_%25DA%25A9%25D9%2588%25D8%25AA%25D8%25A7%25D9%2587%29](/w/index.php?title=%D9%88%DB%8C%DA%98%D9%87:UrlShortener&amp;url=https%3A%2F%2Ffa.wikisource.org%2Fwiki%2F%25D9%2585%25D8%25B1%25DA%25AF_%28%25D9%2586%25D9%2588%25D8%25B4%25D8%25AA%25D9%2587%25E2%2580%258C%25D8%25A7%25DB%258C_%25DA%25A9%25D9%2588%25D8%25AA%25D8%25A7%25D9%2587%29)
- [/w/load.php?lang=fa&amp;modules=ext.dismissableSiteNotice.styles%7Cext.proofreadpage.article%2Cbase%7Cext.uls.interlanguage%7Cext.visualEditor.desktopArticleTarget.noscript%7Cext.wikimediamessages.styles%7Cext.wikisource.icons%7Cmediawiki.widgets.styles%7Coojs-ui-core.icons%2Cstyles%7Coojs-ui.styles.indicators%7Cskins.vector.icons%2Cstyles%7Cskins.vector.search.codex.styles%7Cwikibase.client.init&amp;only=styles&amp;skin=vector-2022](/w/load.php?lang=fa&amp;modules=ext.dismissableSiteNotice.styles%7Cext.proofreadpage.article%2Cbase%7Cext.uls.interlanguage%7Cext.visualEditor.desktopArticleTarget.noscript%7Cext.wikimediamessages.styles%7Cext.wikisource.icons%7Cmediawiki.widgets.styles%7Coojs-ui-core.icons%2Cstyles%7Coojs-ui.styles.indicators%7Cskins.vector.icons%2Cstyles%7Cskins.vector.search.codex.styles%7Cwikibase.client.init&amp;only=styles&amp;skin=vector-2022)
- [/w/load.php?lang=fa&amp;modules=site.styles&amp;only=styles&amp;skin=vector-2022](/w/load.php?lang=fa&amp;modules=site.styles&amp;only=styles&amp;skin=vector-2022)
- [/w/load.php?lang=fa&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector-2022](/w/load.php?lang=fa&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector-2022)
- [/w/rest.php/v1/search](/w/rest.php/v1/search)
- [/wiki/%D8%A7%D8%B5%D9%81%D9%87%D8%A7%D9%86_%D9%86%D8%B5%D9%81_%D8%AC%D9%87%D8%A7%D9%86_(%D8%B3%D9%81%D8%B1%D9%86%D8%A7%D9%85%D9%87)](/wiki/%D8%A7%D8%B5%D9%81%D9%87%D8%A7%D9%86_%D9%86%D8%B5%D9%81_%D8%AC%D9%87%D8%A7%D9%86_(%D8%B3%D9%81%D8%B1%D9%86%D8%A7%D9%85%D9%87))
- [/wiki/%D8%B1%D8%A7%D9%87%D9%86%D9%85%D8%A7:%D8%B1%D8%A7%D9%87%D9%86%D9%85%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87](/wiki/%D8%B1%D8%A7%D9%87%D9%86%D9%85%D8%A7:%D8%B1%D8%A7%D9%87%D9%86%D9%85%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)
- [/wiki/%D8%B1%D8%AF%D9%87:%D8%A2%D8%AB%D8%A7%D8%B1_%D8%B5%D8%A7%D8%AF%D9%82_%D9%87%D8%AF%D8%A7%DB%8C%D8%AA](/wiki/%D8%B1%D8%AF%D9%87:%D8%A2%D8%AB%D8%A7%D8%B1_%D8%B5%D8%A7%D8%AF%D9%82_%D9%87%D8%AF%D8%A7%DB%8C%D8%AA)
- [/wiki/%D8%B1%D8%AF%D9%87:%D9%85%D8%B1%DA%AF](/wiki/%D8%B1%D8%AF%D9%87:%D9%85%D8%B1%DA%AF)
- [/wiki/%D8%B3%D8%A7%D9%85%D9%BE%DB%8C%D9%86%DA%AF%D9%87_(%D8%AF%D8%A7%D8%B3%D8%AA%D8%A7%D9%86_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)](/wiki/%D8%B3%D8%A7%D9%85%D9%BE%DB%8C%D9%86%DA%AF%D9%87_(%D8%AF%D8%A7%D8%B3%D8%AA%D8%A7%D9%86_%DA%A9%D9%88%D8%AA%D8%A7%D9%87))
- [/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C](/wiki/%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%A7%D8%B5%D9%84%DB%8C)
- [/wiki/%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)](/wiki/%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87))
- [/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%AA%D8%BA%DB%8C%DB%8C%D8%B1%D8%A7%D8%AA_%D8%A7%D8%AE%DB%8C%D8%B1](/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%AA%D8%BA%DB%8C%DB%8C%D8%B1%D8%A7%D8%AA_%D8%A7%D8%AE%DB%8C%D8%B1)
- [/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%AA%D8%BA%DB%8C%DB%8C%D8%B1%D8%A7%D8%AA_%D9%85%D8%B1%D8%AA%D8%A8%D8%B7/%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)](/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%AA%D8%BA%DB%8C%DB%8C%D8%B1%D8%A7%D8%AA_%D9%85%D8%B1%D8%AA%D8%A8%D8%B7/%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87))
- [/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%AC%D8%B3%D8%AA%D8%AC%D9%88](/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%AC%D8%B3%D8%AA%D8%AC%D9%88)
- [/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%B1%D8%AF%D9%87%E2%80%8C%D9%87%D8%A7](/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%B1%D8%AF%D9%87%E2%80%8C%D9%87%D8%A7)
- [/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%AA%D8%B5%D8%A7%D8%AF%D9%81%DB%8C](/wiki/%D9%88%DB%8C%DA%98%D9%87:%D8%B5%D9%81%D8%AD%D9%87%D9%94_%D8%AA%D8%B5%D8%A7%D8%AF%D9%81%DB%8C)
- [/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%BE%DB%8C%D9%88%D9%86%D8%AF_%D8%A8%D9%87_%D8%A7%DB%8C%D9%86_%D8%B5%D9%81%D8%AD%D9%87/%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)](/wiki/%D9%88%DB%8C%DA%98%D9%87:%D9%BE%DB%8C%D9%88%D9%86%D8%AF_%D8%A8%D9%87_%D8%A7%DB%8C%D9%86_%D8%B5%D9%81%D8%AD%D9%87/%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87))
- [/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%86%D8%A8%D8%B4%D8%AA%D9%87:%D8%AA%D9%85%D8%A7%D8%B3_%D8%A8%D8%A7_%D9%85%D8%A7](/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%86%D8%A8%D8%B4%D8%AA%D9%87:%D8%AA%D9%85%D8%A7%D8%B3_%D8%A8%D8%A7_%D9%85%D8%A7)
- [/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%86%D8%A8%D8%B4%D8%AA%D9%87:%D8%AA%DA%A9%D8%B0%DB%8C%D8%A8%E2%80%8C%D9%86%D8%A7%D9%85%D9%87%D9%94_%D8%B9%D9%85%D9%88%D9%85%DB%8C](/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%86%D8%A8%D8%B4%D8%AA%D9%87:%D8%AA%DA%A9%D8%B0%DB%8C%D8%A8%E2%80%8C%D9%86%D8%A7%D9%85%D9%87%D9%94_%D8%B9%D9%85%D9%88%D9%85%DB%8C)
- [/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%86%D8%A8%D8%B4%D8%AA%D9%87:%D8%AF%D8%B1%D8%A8%D8%A7%D8%B1%D9%87](/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%86%D8%A8%D8%B4%D8%AA%D9%87:%D8%AF%D8%B1%D8%A8%D8%A7%D8%B1%D9%87)
- [/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%86%D8%A8%D8%B4%D8%AA%D9%87:%D8%AF%D9%81%D8%AA%D8%B1%D8%AE%D8%A7%D9%86%D9%87](/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%86%D8%A8%D8%B4%D8%AA%D9%87:%D8%AF%D9%81%D8%AA%D8%B1%D8%AE%D8%A7%D9%86%D9%87)
- [/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%86%D8%A8%D8%B4%D8%AA%D9%87:%D9%88%D8%B1%D9%88%D8%AF%DB%8C_%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%D8%A7%D9%86](/wiki/%D9%88%DB%8C%DA%A9%DB%8C%E2%80%8C%D9%86%D8%A8%D8%B4%D8%AA%D9%87:%D9%88%D8%B1%D9%88%D8%AF%DB%8C_%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%D8%A7%D9%86)
- [/wiki/%D9%BE%D8%AF%DB%8C%D8%AF%D8%A2%D9%88%D8%B1%D9%86%D8%AF%D9%87:%D8%B5%D8%A7%D8%AF%D9%82_%D9%87%D8%AF%D8%A7%DB%8C%D8%AA](/wiki/%D9%BE%D8%AF%DB%8C%D8%AF%D8%A2%D9%88%D8%B1%D9%86%D8%AF%D9%87:%D8%B5%D8%A7%D8%AF%D9%82_%D9%87%D8%AF%D8%A7%DB%8C%D8%AA)
- [/wiki/%D9%BE%D8%B1%D9%88%DB%8C%D9%86_%D8%AF%D8%AE%D8%AA%D8%B1_%D8%B3%D8%A7%D8%B3%D8%A7%D9%86_%D9%88_%C2%AB%D8%A7%D8%B5%D9%81%D9%87%D8%A7%D9%86_%D9%86%D8%B5%D9%81_%D8%AC%D9%87%D8%A7%D9%86%C2%BB](/wiki/%D9%BE%D8%B1%D9%88%DB%8C%D9%86_%D8%AF%D8%AE%D8%AA%D8%B1_%D8%B3%D8%A7%D8%B3%D8%A7%D9%86_%D9%88_%C2%AB%D8%A7%D8%B5%D9%81%D9%87%D8%A7%D9%86_%D9%86%D8%B5%D9%81_%D8%AC%D9%87%D8%A7%D9%86%C2%BB)
- [auth.wikimedia.org](auth.wikimedia.org)
- [https://creativecommons.org/licenses/by-sa/4.0/deed.fa](https://creativecommons.org/licenses/by-sa/4.0/deed.fa)
- [https://developer.wikimedia.org](https://developer.wikimedia.org)
- [https://donate.wikimedia.org/?wmf_source=donate&amp;wmf_medium=sidebar&amp;wmf_campaign=fa.wikisource.org&amp;uselang=fa](https://donate.wikimedia.org/?wmf_source=donate&amp;wmf_medium=sidebar&amp;wmf_campaign=fa.wikisource.org&amp;uselang=fa)
- [https://fa.wikipedia.org/wiki/%D8%B4%D9%87%D8%B1%D8%B3%D8%AA%D8%A7%D9%86_%DA%AF%D8%A7%D9%86](https://fa.wikipedia.org/wiki/%D8%B4%D9%87%D8%B1%D8%B3%D8%AA%D8%A7%D9%86_%DA%AF%D8%A7%D9%86)
- [https://fa.wikisource.org/w/index.php?title=مرگ_(نوشته‌ای_کوتاه)&amp;oldid=277501](https://fa.wikisource.org/w/index.php?title=مرگ_(نوشته‌ای_کوتاه)&amp;oldid=277501)
- [https://fa.wikisource.org/wiki/%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87)](https://fa.wikisource.org/wiki/%D9%85%D8%B1%DA%AF_(%D9%86%D9%88%D8%B4%D8%AA%D9%87%E2%80%8C%D8%A7%DB%8C_%DA%A9%D9%88%D8%AA%D8%A7%D9%87))
- [https://fa.wikisource.org/wiki/Special:CentralAutoLogin/start?useformat=desktop&amp;type=1x1&amp;usesul3=1](https://fa.wikisource.org/wiki/Special:CentralAutoLogin/start?useformat=desktop&amp;type=1x1&amp;usesul3=1)
- [https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Cookie_statement)
- [https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy](https://foundation.wikimedia.org/wiki/Special:MyLanguage/Policy:Privacy_policy)

## Stats
- Links: 67
- Media: 0
